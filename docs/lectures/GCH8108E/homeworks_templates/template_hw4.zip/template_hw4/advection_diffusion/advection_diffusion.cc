/* ----------------------------------------------------------------------------
 * This problem is to finally solve a PDE using the Finite Element Method with
 * deal.II. Specifically an advection-diffusion equation with and without 
 * stabilization.
 * ----------------------------------------------------------------------------
 */

#include <deal.II/base/function.h>
#include <deal.II/base/quadrature_lib.h>

#include <deal.II/dofs/dof_handler.h>
#include <deal.II/dofs/dof_tools.h>

#include <deal.II/fe/fe_q.h>
#include <deal.II/fe/fe_values.h>

#include <deal.II/grid/grid_generator.h>
#include <deal.II/grid/grid_out.h>
#include <deal.II/grid/tria.h>

#include <deal.II/lac/dynamic_sparsity_pattern.h>
#include <deal.II/lac/full_matrix.h>
#include <deal.II/lac/precondition.h>
#include <deal.II/lac/solver_cg.h>
#include <deal.II/lac/sparse_direct.h>
#include <deal.II/lac/sparse_matrix.h>
#include <deal.II/lac/vector.h>

#include <deal.II/numerics/data_out.h>
#include <deal.II/numerics/matrix_tools.h>
#include <deal.II/numerics/vector_tools.h>

#include <fstream>
#include <iostream>

using namespace dealii;


// Function for the bottom boundary condition in the 2D problem
template <int dim>
class BottomBC : public Function<dim>
{
public:
  virtual double
  value(const Point<dim> &p, const unsigned int component = 0) const override;
};

// TODO: complete the value function. Hint: Use an if for the different
// dimensions.
template <int dim>
double
BottomBC<dim>::value(const Point<dim> &p,
                     const unsigned int /*component*/) const
{
  return 0.0;
}


// Function for the velocity field
template <int dim>
class VelocityField : public Function<dim>
{
public:
  virtual double
  value(const Point<dim> &p, const unsigned int component = 0) const override;
};

// TODO: complete the value function. Hint: Use an if for the different
// dimensions. Hint: the component allow you to distinguish between the x (0) and
// y (1) component of velocity.
template <int dim>
double
VelocityField<dim>::value(const Point<dim>  &p,
                          const unsigned int component) const
{
  return 0.0;
}

// Function for the analytical solution of the 1D problem
template <int dim>
class AnalyticalSolution : public Function<dim>
{
public:
  AnalyticalSolution(double Pe)
    : Pe(Pe)
  {}

  virtual double
  value(const Point<dim> &p, const unsigned int component = 0) const override;

private:
  double Pe;
};

// TODO: complete the value function. Hint: Use an if for the different
// dimensions.
template <int dim>
double
AnalyticalSolution<dim>::value(const Point<dim> &p,
                               const unsigned int /*component*/) const
{
  return 0.0;
}

// Main class to solve the advection diffusion equation in different dimensions
template <int dim>
class AdvectionDiffusion
{
public:
  AdvectionDiffusion(const bool         stabilized,
                     const unsigned int refinement,
                     const double       Pe);
  void
  run();

private:
  /**
   * @brief setup_triangulation Sets-up the triangulation. This is where you will create the grid
   * // TODO - Go and complete this function
   */
  void
  setup_triangulation();

  /**
   * @brief setup_system This part generates the sparsity pattern and allocates the memory for the matrix, the right-hand side and the solution.
   */
  void
  setup_system();

  /**
   * @brief assemble_system Assembles the matrix and the right-hand side
   * // TODO - Go and complete this function
   */
  void
  assemble_system();

  /**
   * @brief Solve_linear_system Solves the linear system of equation that arise from the problem
   */
  void
  solve_linear_system();

  /**
   * @brief Solve_linear_system Solves the linear system of equation that arise from the problem
   */
  void
  calculate_L2_error();

  /**
   * @brief output_results Outputs the results of the simulation into vtk files for Paraview.
   */
  void
  output_results() const;

  bool               stabilized;
  double             Pe;
  unsigned int       refinement;
  Triangulation<dim> triangulation;
  FE_Q<dim>          fe;
  DoFHandler<dim>    dof_handler;
  MappingQ<dim>      mapping;


  SparsityPattern      sparsity_pattern;
  SparseMatrix<double> system_matrix;

  Vector<double> solution;
  Vector<double> system_rhs;
};


template <int dim>
AdvectionDiffusion<dim>::AdvectionDiffusion(const bool         stabilized,
                                            const unsigned int refinement,
                                            const double       Pe)
  : stabilized(stabilized)
  , Pe(Pe)
  , refinement(refinement)
  , fe(1)
  , dof_handler(triangulation)
  , mapping(1)
{}

template <int dim>
void
AdvectionDiffusion<dim>::setup_triangulation()
{
  // We use the dimensions to seperate the two cases
  if constexpr (dim == 1)
    {
      // TODO: Generate the mesh for the 1D problem and refine it globally. Use
      // the refinement variable.
    }

  if constexpr (dim == 2)
    {
      // TODO: Generate the mesh for the 2D problem and refine it globally. Use
      // the refinement variable.
    }

  std::cout << "   Number of active cells: " << triangulation.n_active_cells()
            << std::endl
            << "   Total number of cells: " << triangulation.n_cells()
            << std::endl;
}

template <int dim>
void
AdvectionDiffusion<dim>::setup_system()
{
  // This call enumerates the DoFs
  dof_handler.distribute_dofs(fe);

  std::cout << "   Number of degrees of freedom: " << dof_handler.n_dofs()
            << std::endl;

  // Here, we create a sparsity pattern, i.e. a structure used to store
  // the places of non-zero elements. Then it is passed to the system_matrix.
  DynamicSparsityPattern dsp(dof_handler.n_dofs());
  DoFTools::make_sparsity_pattern(dof_handler, dsp);
  sparsity_pattern.copy_from(dsp);
  system_matrix.reinit(sparsity_pattern);

  // Here we set the appropriate sizes of the solution vector and the right hand
  // side
  solution.reinit(dof_handler.n_dofs());
  system_rhs.reinit(dof_handler.n_dofs());
}

template <int dim>
void
AdvectionDiffusion<dim>::calculate_L2_error()
{
  // Analytical solution
  AnalyticalSolution<dim> analytical(Pe);

  // Create a Gauss Quadrature with the appropriate dimension and degree
  const QGauss<dim> quadrature_formula(fe.degree + 1);

  // Here, we create an FEValues object of dimension 1 by passing the finite
  // element, the quadrature formula and other flags as parameters.
  FEValues<dim> fe_values(mapping,
                          fe,
                          quadrature_formula,
                          update_values | update_JxW_values |
                            update_quadrature_points);

  // Extract the number of quadrature points from the fe_values object
  const unsigned int n_q_points = fe_values.n_quadrature_points;

  // Create a variable to store the integration result
  double L2_error = 0;

  // Create an std::vector which will contain all the interpolated values at the
  // gauss points
  std::vector<double> values(n_q_points);

  // Now we loop over all the cells
  for (auto cell : dof_handler.active_cell_iterators())
    {
      // This call reinitializes the valuess, determinants, and other relevant
      // information for the given cell. This is an expensive but needed call.
      fe_values.reinit(cell);

      fe_values.get_function_values(solution, values);

      // Loop over all quadrature points of each cell
      for (unsigned int q = 0; q < n_q_points; q++)
        {
          // This call extracts the Jacobi determinant times the weight
          // of the quadrature point
          const double JxW = fe_values.JxW(q);

          // quadrature point
          double analytical_solution =
            analytical.value(fe_values.get_quadrature_points()[q]);

          // With all the previous elements calculate the contribution to the
          // integral and add it to the integration result variable
          L2_error += std::pow((values[q] - analytical_solution), 2) * JxW;
        }
    }

  std::cout << "L2 error is : " << std::sqrt(L2_error) << std::endl;
}

template <int dim>
void
AdvectionDiffusion<dim>::assemble_system()
{
  QGauss<dim> quadrature_formula(fe.degree + 1);

  // To solve our problem, we will need to have the values of the shape
  // function, the gradient of the shape function, the hessian of the shape
  // function, the location of the quadrature points and the JxW values. Thus we
  // update these fields with the FeValues class. The hessian of the shape
  // function is a new thing we introduce here. We need it to calculate the
  // strong residual which we will use in the stabilization.
  FEValues<dim> fe_values(mapping,
                          fe,
                          quadrature_formula,
                          update_values | update_gradients | update_hessians |
                            update_quadrature_points | update_JxW_values);

  // We need to know how many degrees of freedom we have per cell.
  // The degrees of freedom are the colocation point, the points which
  // we use to carry out our interpolation.
  const unsigned int dofs_per_cell = fe.n_dofs_per_cell();


  // We create cell matrices and cell rhs to store the information
  // of the integral over the cell as we are building it
  FullMatrix<double> cell_matrix(dofs_per_cell, dofs_per_cell);
  Vector<double>     cell_rhs(dofs_per_cell);

  // We will store the index in the "big" matrix of the degrees of freedom
  // in the cell using this vector here. Don't be afraid of
  // types::global_dof_index It is nothing more than an unsigned integer (an
  // integer without a sign bit)
  std::vector<types::global_dof_index> local_dof_indices(dofs_per_cell);


  // We define the velocity field using a function. This will enable us
  // to calculate the velocity quite easily. You will see that the notion of
  // component will be very useful here.
  VelocityField<dim> vel_field;

  // Next, we again have to loop over all cells and assemble local
  // contributions.  Note, that a cell is a quadrilateral in two space
  // dimensions, but a hexahedron in 3D. In fact, the
  // <code>active_cell_iterator</code> data type is something different,
  // depending on the dimension we are in, but to the outside world they look
  // alike and you will probably never see a difference.
  for (const auto &cell : dof_handler.active_cell_iterators())
    {
      fe_values.reinit(cell);
      cell_matrix = 0;
      cell_rhs    = 0;

      // Now we have to assemble the local matrix and right hand side.
      for (const unsigned int q_index : fe_values.quadrature_point_indices())
        {
          const auto &x_q = fe_values.quadrature_point(q_index);

          // Create a tensor to store the values of the velocity field for
          // this quadrature point AND evaluate the value for all the dimensions
          // using a loop
          Tensor<1, dim> u;
          for (int i = 0; i < dim; ++i)
            u[i] = vel_field.value(x_q, i);

          for (const unsigned int i : fe_values.dof_indices())
            {
              for (const unsigned int j : fe_values.dof_indices())
                {
                  // TODO: assemble the cell_matrix for the component i j. Hint:
                  // use the fe_values.shape_grad(...)
                  cell_matrix(i, j) += 0.0;


                  // We have already coded the stabilization for you
                  // Take the time to read it, it's not so trivial to
                  // understand!
                  if (stabilized)
                    {
                      double h   = cell->measure();
                      double tau = std::pow(std::pow(4 / (Pe * h * h), 2) +
                                              std::pow(2 * u.norm() / h, 2),
                                            -0.5);
                      auto   shape_hessian_j =
                        fe_values.shape_hessian(j, q_index);

                      auto shape_laplacian_j = trace(shape_hessian_j);
                      cell_matrix(i, j) +=
                        ((u * fe_values.shape_grad(j, q_index)) -
                         (1. / Pe * shape_laplacian_j)) *
                        (tau * (u * fe_values.shape_grad(i, q_index))) *
                        fe_values.JxW(q_index); // dx
                    }
                }
            }
        }

      // Here we simply add each cell matrix to the global system matrix
      cell->get_dof_indices(local_dof_indices);
      for (const unsigned int i : fe_values.dof_indices())
        {
          for (const unsigned int j : fe_values.dof_indices())
            system_matrix.add(local_dof_indices[i],
                              local_dof_indices[j],
                              cell_matrix(i, j));

          system_rhs(local_dof_indices[i]) += cell_rhs(i);
        }
    }

  // As the final step in this function, we wanted to have non-homogeneous
  // boundary values and homogenous boundary values. These boundary
  // values are imposed using the VectorTool utilities.

  std::map<types::global_dof_index, double> boundary_values;
  if (dim == 1)
    {
      // TODO: impose the boundary conditions for the 1D problem
    }
  if (dim == 2)
    {
      // TODO: impose the boundary conditions. Hint: As we have a very specific
      //  boundary condition on the bottom wall, use the custom defined BottomBC
      //  function created at the beginning of this file
    }

  // This applies the boundary conditions on the system matrix.
  MatrixTools::apply_boundary_values(boundary_values,
                                     system_matrix,
                                     solution,
                                     system_rhs);
}

template <int dim>
void
AdvectionDiffusion<dim>::solve_linear_system()
{
  // We use a sparse direct solver to solve the equations
  // We could also use an iterative solver. It would have been more efficient.
  SparseDirectUMFPACK A_direct;
  A_direct.initialize(system_matrix);
  A_direct.vmult(solution, system_rhs);
}

template <int dim>
void
AdvectionDiffusion<dim>::output_results() const
{
  DataOut<dim> data_out;

  data_out.attach_dof_handler(dof_handler);
  data_out.add_data_vector(solution, "solution");

  data_out.build_patches();


  std::string filename =
    "solution-" + Utilities::int_to_string(int(Pe)) + ".vtu";
  if (dim == 2 && stabilized)
    filename = "solution-stabilized-2d.vtu";
  else if (dim == 2)
    filename = "solution-2d.vtu";
  std::ofstream output(filename);
  data_out.write_vtu(output);

  // Calculate raw interpolation data in .dat format.
  std::string dat_filename;
  if (stabilized)
    dat_filename = "stabilized_solution-" + Utilities::int_to_string(int(Pe)) +
                   "-" + Utilities::int_to_string(refinement) + ".dat";
  else
    dat_filename = "solution-" + Utilities::int_to_string(int(Pe)) + "-" +
                   Utilities::int_to_string(refinement) + ".dat";

  if (dim == 1)
    {
      std::ofstream f(dat_filename);
      f << "x interpolation(x)" << std::endl;
      f << std::scientific;
      Point<dim> p;
      p[0] = 0;


      for (unsigned int i = 0; i <= 1000; ++i)
        {
          p[0] = i / 1000.0;

          Vector<double> tmp_vector(1);
          VectorTools::point_value(dof_handler, solution, p, tmp_vector);
          f << p[0] << " " << tmp_vector[0];
          f << std::endl;
        }
    }
}

template <int dim>
void
AdvectionDiffusion<dim>::run()
{
  std::cout << "Solving problem in " << dim << " space dimensions."
            << std::endl;

  setup_triangulation();
  setup_system();
  assemble_system();
  solve_linear_system();
  calculate_L2_error();
  output_results();
}

int
main()
{
  // Here we create the different advection diffusion problems
  {
    // TODO: using loops create the AdvectionDiffusion objects to
    // complete all the parts of the 1.1. exercise

  } {
    // TODO: Create the necessary objects for the 2D problem and complete
    // exercise 1.2
  }

  return 0;
}
