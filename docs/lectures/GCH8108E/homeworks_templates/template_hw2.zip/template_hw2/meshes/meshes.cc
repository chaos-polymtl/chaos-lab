/* ---------------------------------------------------------------------
 * This problem is there to familiarize yourself with the basics of 
 * meshes in deal.II. It consists of creating a mesh and reading a gmsh
 * file. Also, we will work with the refinement of the mesh by certain 
 * criteria, for this you will need to loop over all cells.
 * ---------------------------------------------------------------------
 */

// This is the Triangulation class that is in charge of the mesh in deal.II.
// You will see this class in every deal.II program. It is documented here:
// https://www.dealii.org/developer/doxygen/deal.II/classTriangulation.html
#include <deal.II/grid/tria.h>

// The grid generator has several functions to create standard meshes in
// different dimensions, e.g., hypercubes, hyperballs, hypershells, etc
#include <deal.II/grid/grid_generator.h>

// The grid out class helps us to ouput the mesh in different formats.
#include <deal.II/grid/grid_out.h>

// The grid in class is used to read an external mesh file.
#include <deal.II/grid/grid_in.h>

// The rest of the includes are standard C++ includes
#include <cmath>
#include <iostream>
#include <fstream>

using namespace dealii;

void
print_mesh_information_2d(const Triangulation<2> &triangulation)
{
  // We can get a lot of information about the mesh. Here we get the number of cells.
  // TODO: complete the empty lines and check in the documentation what other information
  // could be useful. Add a description of the new parameters you printed in the report.

  std::cout << "   Mesh information:" << std::endl;
  std::cout << "   - Dimension: 2" << std::endl;
  std::cout << "   - No. of cells: " << triangulation.n_active_cells() << std::endl;
  std::cout << "   - No. of faces: "  << std::endl;
  std::cout << "   - No. of vertices: " << std::endl;
}

// TODO: complete the function to print information of the mesh in 3D 
void
print_mesh_information_3d()
{

}

void 
create_quadrant_2d()
{
  std::cout << "########################################" << std::endl;
  std::cout << "  Creating quadrant grid..." << std::endl;

  // The main class when creating a mesh is the Triangulation class.
  // It is a collection of cells that covers the domain on which one wants
  // to solve a PDE. It is a templated class, in this case we instantiate a 2D
  // triangulation object.
  Triangulation<2> triangulation;

  // Using the grid generator of deal.ii we create a quadrant.
  // Use the hyper_cube function to create the appropriate domain by passing
  // the triangulation as parameter. 
  // TODO

  // So far this consists of only a square. Therefore use the refine_global call
  // that takes the number of global refinements as parameter 
  // TODO

  std::cout << "  Refining quadrant grid..." << std::endl;

  // Now we refine the geometry according to a criteria for a total number of refinements. For this we need to loop
  // over all cells using what is called an "active_cell_iterator"

  // TODO define a number_of_refinements parameter

  for (unsigned int i = 1; i < number_of_refinements; i++)
  {
    // A triangulation object is powerful because we can loop over 
    // all its cells in a straightforward way. This is not easy to
    // implement efficiently but deal.II does it for us. We will
    // go through each of the cells, check the refinement criteria
    // and clasify a cell for refinement by using cell->set_refine_flag().

    for (auto &cell: triangulation.active_cell_iterators())
    {
      // Check criteria using cell->center(). Hint: the center of a cell in 2D 
      // is a point. 
      
      // TODO

      cell->set_refine_flag();

    }

    // The following function executes refinement and coarsening (coarsening is not used in this example)
    // according to the refinement flag set in the previous step. 
    triangulation.execute_coarsening_and_refinement();
  }

  // In the following lines we set the name of the output file, create a grid out
  // object and write a VTK file with the mesh, This VTK file can be opened in Paraview.

  std::ofstream out("quadrant_grid.vtk");
  GridOut grid_out;
  grid_out.write_vtk(triangulation, out);

  std::cout << "  Quadrant grid written to quadrant_grid.vtk" << std::endl;

  // Now you can print important information of the mesh, for this
  // an additional print mesh information function is written, go there
  // and complete the code:
  print_mesh_information_2d(triangulation);

  std::cout << "########################################" << std::endl;

}

void
create_annulus_3d()
{
  std::cout << "########################################" << std::endl;
  std::cout << "  Creating annulus grid..." << std::endl;

  // Create the object of the 3D triangulation
  // TODO

  // Create the annulus
  // TODO

  // Refine globally the triangulation according to homework instructions
  // TODO

  std::cout << "  Refining annulus grid..." << std::endl;
  // Now we refine the geometry according to a criteria. For this we need to loop
  // over all cells using what is called an "active_cell_iterator". Hint: create
  // a separate loop for each criteria and execute refinement after each loop. Use
  // the cell->center().norm() call.

  // TODO

  // Assign a different material_id for some of the cells in the shell between radius
  // 0.335 and 0.55 by using the cell->set_material_id() call.
  // TODO

  // Output the vtk file with the grid
  // TODO

  std::cout << "  Annulus grid written to annulus_grid.vtk" << std::endl;

  // Complete the print_mesh_information_3d function and use it to print
  // important information.
  // TODO

  std::cout << "########################################" << std::endl;
}

void
read_gmsh_file()
{
  std::cout << "########################################" << std::endl;

  std::cout << "  Reading gmsh file..." << std::endl;

  // Allocate a 2D triangulation object 
  // TODO

  // Create a GridIn object in a similar way to the GridOut object
  // TODO

  // Use the attach_triangulation and read_msh functions to read the .msh file
  // TODO

  // Use grid out to output the vtk file of the mesh
  // TODO

  std::cout << "  Cylinder grid written to cylinder_grid.svg" << std::endl;

  // Print the mesh information reusing one of the print mesh functions
  // TODO

  std::cout << "########################################" << std::endl;
}

int
main()
{
  /*
   * Complete all functions one by one. They are well documented and they will
   * guide you through the results. For all the following homeworks you will
   * generate or read a mesh.
   */

  create_quadrant_2d();

  create_annulus_3d();

  read_gmsh_file();

}
