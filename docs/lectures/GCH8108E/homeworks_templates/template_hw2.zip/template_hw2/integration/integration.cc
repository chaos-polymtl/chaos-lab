/* ---------------------------------------------------------------------
 * This problem is there to familiarize yourself with the basic of 
 * meshes in deal.II. It consists of creating a mesh and reading a gmsh
 * file. Also, we will work with the refinement of the mesh by certain 
 * criteria, for this you will need to loop over all cells.
 * ---------------------------------------------------------------------
 */

// This is the Triangulation class that is in charge of the mesh in deal.II.
// You will see this class in every deal.II program. It is documented here:
// https://www.dealii.org/developer/doxygen/deal.II/classTriangulation.html
#include <deal.II/grid/tria.h>

// The grid generator has several functions to great standard meshes in
// different dimensions, e.g., hypercubes, hyperballs, hypershells, etc
#include <deal.II/grid/grid_generator.h>

// You should be familiar with the Function class form homework 1
#include <deal.II/base/function.h>

// This class has the implementation of scalar Lagrange finite elements that
// lead to the finite element space of piecewise polynomials of certain degree 
// in each coordinate direction. It is documented here:
// https://www.dealii.org/developer/doxygen/deal.II/classFE__Q.html
// There are many types of elements in deal.II but this is the most common one.
#include <deal.II/fe/fe_q.h>

// There are many quadrature rules implemented in deal.II 
// (https://www.dealii.org/developer/doxygen/deal.II/group__Quadrature.html)
// this one corresponds to the Gauss-Legendre family, commonly called Gauss
// quadrature.
#include <deal.II/base/quadrature_lib.h>

// The FEValues class is what connects the finite element (shape functions) and
// the quadrature rule. It is in charge of evaluating shape functions at the points
// defined by the equadrature formula when mapped to the real cell.
// https://www.dealii.org/developer/doxygen/deal.II/classFEValues.html
#include <deal.II/fe/fe_values.h>

#include <cmath>
#include <iostream>
#include <fstream>

using namespace dealii;

// Function that we wish to integrate in 2D. Fill the value function as
// in the previous homework with the appropriate function.
template <int dim>
class SineFunction : public Function <dim>
{
public:
  virtual double
  value(const Point<dim> &p, const unsigned int) const override;
};

template <int dim>
double
SineFunction<dim>::value(const Point<dim> &p, const unsigned int) const
{
  // TODO
  return 0.0;
}

// Function that we wish to integrate in 3D. Create the class below.
// TODO

// This function does the integration of the exercise 1 of homework 1 
// but using the deal.ii objects. It's equivalent to finding the area
// under the curve.
void integrate_1d()
{ 
  std::cout << "#################### INTEGRATION 1D ####################" << std::endl;

  // Create the triangulation
  // TODO

  // Create the appropriate domain
  // TODO

  // Refine the mesh uniformly 
  // TODO

  // Create a FE of dimension 1 and degree 1. Use FE_Q.
  // TODO

  // Create a Gauss Quadrature with the appropriate dimension and degree
  // TODO

  // Here, we create an FEValues object of dimension 1 by passing the finite 
  // element, the quadrature formula and other flags as parameters.
  FEValues<1> fe_values(fe,
                          quadrature_formula,
                          update_values | update_JxW_values |
                            update_quadrature_points);

  // Extract the number of quadrature points from the fe_values object
  // TODO

  // Create a variable to store the integration result
  // TODO

  // Now we loop over all the cells
  for (auto cell: triangulation.active_cell_iterators())
  {
    // This call reinitializes the gradients, determinants, and other relevan information
    // for the given cell. This is an expensive but needed call.
    fe_values.reinit(cell);

    // Loop over all quadrature points of each cell
    for (unsigned int q = 0; q < n_q_points; q++)
    {
      // This call extracts the Jacobi determinant times the weight
      // of the quadrature point
      const double dx = fe_values.JxW(q);

      // The following call extracts one of the components of the
      // quadrature point
      double x_coordinate_for_q = fe_values.get_quadrature_points()[q][0];

      // With all the previous elements calculate the contribution to the integral
      // and add it to the integration result variable
      // TODO

    }
  }

  // Output the result and the absolute error with respect to the analytical solution.
  // TODO
}

// This function integrates sin(x)sin(y). It is very similar to the integration in 1D
// but now we use an additional class for the function we want to evaluate. Go above
// to SineFunction and complete it. Then come back to continue with the integration.
void integrate_2d()
{ 
  std::cout << "#################### INTEGRATION 2D ####################" << std::endl;

  // Create the triangulation
  // TODO

  // Create the appropriate domain
  // TODO

  // Refine the mesh uniformly 
  // TODO

  // Create an object of the SineFunction completed above
  // TODO

  // Create a finite element with the appropriate dimension
  // TODO

  // Create a Gauss Quadrature with the appropriate dimension and degree
  // TODO

  // Create the FEValues object 
  // TODO

  // Extract number of quadrature points
  // TODO

  // Create a variable to store the integration result
  // TODO

  // The following line creates a vector where we will store the values
  // of the function per cell.
  std::vector<double> sine_function_values(n_q_points);

  // Now we loop over all the cells
  for (auto cell: triangulation.active_cell_iterators())
  {
    // Reinitialize the information for the given cell using the FEValues object
    // TODO

    // This function fills the vector with the sine_function_values for this cell
    fct.value_list(fe_values.get_quadrature_points(),
                                   sine_function_values);

    // Loop over all quadrature points
    for (unsigned int q = 0; q < n_q_points; q++)
    {
      // Extract the dx using the fe_values object
      // TODO

      // Calculate the contribution to the integral and add it to the integration result variable
      // TODO
    }
  }

  // Output the result 
  // TODO

}

// This function integrates xyz. It is very similar to the integration in 2D. First,
// go above and create the appropriate class for the function to be integrated. Then 
// come back to continue with the integration.
void integrate_3d()
{
  std::cout << "#################### INTEGRATION 3D ####################" << std::endl;

  // Create the triangulation
  // TODO

  // Create the appropriate domain
  // TODO

  // Refine the mesh uniformly 
  // TODO

  // Create an object of the function to be integrated (completed above)
  // TODO

  // Create a finite element with the appropriate dimension
  // TODO

  // Create a Gauss Quadrature with the appropriate dimension and degree
  // TODO

  // Create the FEValues object 
  // TODO

  // Extract number of quadrature points
  // TODO

  // Create a variable to store the integration result
  // TODO

  // Create a vector where we will store the values of the function per cell
  // TODO

  // Now loop over all cells and perform the integration in a very similar way 
  // to the 2D case. 
  // TODO

  // Output the result
  // TODO
  
}

int
main()
{
  /*
   * Complete all functions one by one. They are well documented and they will
   * guide you through the results.
   */

  integrate_1d();

  integrate_2d();

  integrate_3d();
}
